package com.one.member;
import com.one.weixin.entity.AppEntity;

public interface MemberService {

	/*
	 * 会员服务调用微信接口
	 */
	public AppEntity memberInvokeWeixin();
}
