package com.one.weixin.service;

import org.springframework.web.bind.annotation.GetMapping;

import com.one.weixin.entity.AppEntity;

/**
 * 微信服务接口
 * @author 陈远波
 *
 */
public interface WeiXinAppService {

	/**
	 * 应用服务接口
	 * @return
	 */
	@GetMapping("/getApp")
	public AppEntity getApp();
}
