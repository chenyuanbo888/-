package com.one.member.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.one.member.MemberService;
import com.one.member.feign.WeixinAppServiceFeign;
import com.one.weixin.entity.AppEntity;
import com.one.weixin.service.WeiXinAppService;

@RestController
public class MemberServiceImpl implements MemberService{

	@Autowired
	private WeixinAppServiceFeign weixinAppServiceFeign;
	
	

	@GetMapping("/memberInvokeWeixin")
	@Override
	public AppEntity memberInvokeWeixin() {
		// TODO Auto-generated method stub
		return weixinAppServiceFeign.getApp();
	}

}
