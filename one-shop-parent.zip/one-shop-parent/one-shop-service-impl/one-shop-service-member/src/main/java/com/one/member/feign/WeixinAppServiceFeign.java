package com.one.member.feign;

import org.springframework.cloud.openfeign.FeignClient;

import com.one.weixin.service.WeiXinAppService;

@FeignClient(name="app-one-weixin")
public interface WeixinAppServiceFeign extends WeiXinAppService{

}
