package com.one.weixin.service.impl;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.one.weixin.entity.AppEntity;
import com.one.weixin.service.WeiXinAppService;

/**
 * 微信服务接口的实现
 * @author 陈远波
 *
 */
@RestController
public class WeiXinAppServiceImpl implements WeiXinAppService {

	@GetMapping("/getApp")
	public AppEntity getApp() {
		// TODO Auto-generated method stub
		AppEntity app= new AppEntity("appId:","appName");
		return app;
	}

}
