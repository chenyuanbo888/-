package cn.temptation.utils.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;

/**
 * 以静态变量保存Spring ApplicationContext,可在任意代码中取出ApplicaitonContext.
 */
public class SpringContextHolder implements ApplicationContextAware {

    /**ConfigurableApplicationContext
     *  在ApplicationContext的基础上增加了一系列配置应用上下文的功能
     * */
    private static ConfigurableApplicationContext applicationContext;

    /**
     * 实现ApplicationContextAware接口的context注入函数, 将其存入静态变量.
     */
    public void setApplicationContext(ApplicationContext applicationContext) {
        SpringContextHolder.applicationContext = (ConfigurableApplicationContext) applicationContext;
        //System.out.println("spring容器在项目构建的时候就执行了");
        //String[] beanDefinitionNames = applicationContext.getBeanDefinitionNames();
        //for (String beanDefinitionName : beanDefinitionNames) {
        //    //beanDefinitionName是容器中bean实例的id
        //    //<bean id="">对应此处的id
        //    System.out.println(beanDefinitionName);
        //}
        //System.out.println("结束!!!");
    }


    /**
     * 取得存储在静态变量中的ApplicationContext.
     */
    public static ApplicationContext getApplicationContext() {
        checkApplicationContext();
        return applicationContext;
    }

    /**
     * 从静态变量ApplicationContext中取得Bean, 自动转型为所赋值对象的类型.
     */
    @SuppressWarnings("unchecked")
    public static <T> T getBean(String name) {
        checkApplicationContext();
        return (T) applicationContext.getBean(name);
    }

    /**
     * 是否包含某个bean
     *
     * @param beanName
     * @return
     */
    public static boolean containsBean(String beanName) {
        return applicationContext.containsBean(beanName);
    }

    /**
     * 从静态变量ApplicationContext中取得Bean, 自动转型为所赋值对象的类型.
     */
    @SuppressWarnings("unchecked")
    public static <T> T getBean(Class<T> clazz) {
        checkApplicationContext();
        return applicationContext.getBean(clazz);
    }

    private static void checkApplicationContext() {
        if (applicationContext == null)
            throw new IllegalStateException("applicaitonContext未注入,请在applicationContext.xml中定义SpringContextUtil");
    }

}