package cn.temptation.shiro.filter;


import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: LogoutFilter.java
 * Description: 登出拦截
 * Author: Ali.Cao
 * CreateDate: 2018/5/29
 * --------------------------------------------------------------
 */
public class LogoutFilter extends  org.apache.shiro.web.filter.authc.LogoutFilter{
 /*   @Autowired
    AbstractUserService abstractUserService;*/

    @Override
    protected boolean preHandle(ServletRequest request, ServletResponse response) throws Exception {
      /*  SecurityUser user =(SecurityUser) SecurityUtils.getSubject().getSession().getAttribute("user");
        if(null != user){
            abstractUserService.removeIfExistUserIdFromCurrentUserServiceStaffList(user.getName());
        }*/
        return super.preHandle( request,  response);
    }

}
