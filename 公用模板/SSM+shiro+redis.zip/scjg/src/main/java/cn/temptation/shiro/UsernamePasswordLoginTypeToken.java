package cn.temptation.shiro;

import org.apache.shiro.authc.UsernamePasswordToken;

/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: UsernamePasswordLoginTypeToken.java
 * Description:
 * Author: ljx
 * CreateDate: 2018-07-17
 * --------------------------------------------------------------
 */

public class UsernamePasswordLoginTypeToken extends UsernamePasswordToken {

    private static final long serialVersionUID = 1L;

    private String utoken;
    private String uphoneNum;
    private String loginType = "0";// 0为用户密码登录，1为第三方登录登录
    private String captcha;
    private String isExpert; // 判断是企业用户还是个人（专家）用户

    public UsernamePasswordLoginTypeToken() {
        super();
    }

    public String getUtoken() {
        return utoken;
    }

    public void setUtoken(String utoken) {
        this.utoken = utoken;
    }

    public String getUphoneNum() {
        return uphoneNum;
    }

    public void setUphoneNum(String uphoneNum) {
        this.uphoneNum = uphoneNum;

    }

    public String getLoginType() {
        return loginType;
    }

    public void setLoginType(String loginType) {
        this.loginType = loginType;
    }

    public UsernamePasswordLoginTypeToken(final String username, final String password,
                                          final boolean rememberMe, String loginType, String utoken) {
        super(username, password, rememberMe);
        this.loginType = loginType;
        this.utoken = utoken;
        //this.uphoneNum = uphoneNum;
    }

    public UsernamePasswordLoginTypeToken(final String username, final String password,
                                          final boolean rememberMe, String loginType,
                                          String utoken,String captcha,String isExpert) {
        super(username, password, rememberMe);
        this.loginType = loginType;
        this.utoken = utoken;
        //this.uphoneNum = uphoneNum;
        this.captcha = captcha;
        this.isExpert = isExpert;
    }


    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public String getIsExpert() {
        return isExpert;
    }

    public void setIsExpert(String isExpert) {
        this.isExpert = isExpert;
    }
}
