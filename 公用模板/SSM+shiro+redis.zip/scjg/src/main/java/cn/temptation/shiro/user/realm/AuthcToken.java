package cn.temptation.shiro.user.realm;

import org.apache.shiro.authc.UsernamePasswordToken;

/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: AuthcToken.java
 * Description:
 * Author: Ali.Cao
 * CreateDate: 2018/6/20
 * --------------------------------------------------------------
 */
public class AuthcToken extends UsernamePasswordToken {

    private static final long serialVersionUID = 1540276401874522166L;
    private String uid ;

    public AuthcToken(final String username, final String password) {
        super(username,password);
    }

    public AuthcToken(String uid, final String username, final String password) {
        super(username,password);
        this.uid=uid;
    }

    public String getUid() {
        return uid;
    }
}
