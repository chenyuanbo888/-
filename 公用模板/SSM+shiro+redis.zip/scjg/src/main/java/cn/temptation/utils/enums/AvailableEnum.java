package cn.temptation.utils.enums;



/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: AvailableEnum.java
 * Description:
 * Author: zhicheng.wang
 * CreateDate: 2019/2/22
 * --------------------------------------------------------------
 */
public enum AvailableEnum {

    ENABLE("1","启用"),

    PROHIBIT("2","禁用"),

    NO_AVAIL("0","无效");

    private String index;

    private String name;

    AvailableEnum(String index, String name) {
        this.index = index;
        this.name = name;
    }

    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    public static String getName(String index){
        AvailableEnum[] enums = AvailableEnum.values();
        for (AvailableEnum eventEnum : enums){
            if (eventEnum.getIndex().equals(index)){
                return eventEnum.getName();
            }
        }
        return "";
    }
}
