package cn.temptation.service;

import java.util.List;

/**
 * Redis 服务接口定义
 *
 * @author
 * @create 2018-04-02 17:19
 **/
public interface RedisService {

    boolean set(String key, String value);

    String get(String key);

    boolean expire(String key, long expire);//过期时间

    <T> boolean setList(String key, List<T> list);

    <T> List<T> getList(String key, Class<T> clz);

    long lpush(String key, Object obj);

    long rpush(String key, Object obj);

    String lpop(String key);

    <T> T get(String key, Class<T> clz);

    boolean delete(String key);
}
