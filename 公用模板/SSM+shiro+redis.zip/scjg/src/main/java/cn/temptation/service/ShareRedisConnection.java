package cn.temptation.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.stereotype.Service;
import redis.clients.jedis.JedisPoolConfig;

import javax.annotation.PostConstruct;

/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: ShareRedisConnection.java
 * Description:
 * Author: Ali.Cao
 * CreateDate: 2018/5/28
 * --------------------------------------------------------------
 */
@Service(value="shareRedisConnection")
public class ShareRedisConnection {

    @Autowired
    private JedisPoolConfig jedisPoolConfig;

    @Value("${share.redis.ip}")
    private String hostName;

    @Value("${share.redis.port}")
    private int port;

    @Value("${share.redis.password}")
    private String password;

    @Value("${share.redis.database}")
    private int dbIndex;

    private JedisConnectionFactory jedisConnectionFactory;

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getDbIndex() {
        return dbIndex;
    }

    public void setDbIndex(int dbIndex) {
        this.dbIndex = dbIndex;
    }

    public JedisConnectionFactory getJedisConnectionFactory() {
        return jedisConnectionFactory;
    }


    @PostConstruct
    public void createRedisConnection() throws Exception
    {
        jedisConnectionFactory=new JedisConnectionFactory(jedisPoolConfig);
        jedisConnectionFactory.setHostName(this.getHostName());
        jedisConnectionFactory.setPort(this.getPort());
        jedisConnectionFactory.setPassword(this.getPassword());
        jedisConnectionFactory.setDatabase(this.getDbIndex());
        jedisConnectionFactory.afterPropertiesSet();
    }

}
