package cn.temptation.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import cn.temptation.domain.Principal;
import cn.temptation.utils.AjaxJsonMap;
import cn.temptation.utils.UserUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.temptation.dao.UserDao;
import cn.temptation.domain.User;

import java.util.Map;

@Controller
@RequestMapping("/user")
public class UserController {

    @Resource
    private UserDao userDao;

    @RequestMapping("view")
    public String view() {
        return "/login";
    }

    @RequestMapping("/indexview")
    public String index() {
        return "main/index";
    }

    @RequestMapping(value = "/login")
    @ResponseBody
    public Map<String, Object> login(User userInfo, HttpSession session) {
        // 获取当前的用户
        Subject subject = SecurityUtils.getSubject();
        subject.logout();  // 登录之前先logout一下，退出之前的登录，反正重复登录

        //生成token
        UsernamePasswordToken token = new UsernamePasswordToken(userInfo.getUserName(),userInfo.getPassword());
        try{
            // 对当前用户使用login方法提交认证
            subject.login(token);
            //
            Principal p = UserUtils.getPrincipal();
           return AjaxJsonMap.success("登录成功", p);
        } catch (UnknownAccountException uae) {
            //LOGGER.info("用户名为【" + token.getPrincipal() + "】不存在");
            uae.printStackTrace();
            return AjaxJsonMap.error("用户名为【" + token.getPrincipal() + "】不存在。");
        } catch (IncorrectCredentialsException ice) {
            //LOGGER.info("用户名为【 " + token.getPrincipal() + " 】密码错误！");
            ice.printStackTrace();
            return AjaxJsonMap.error("用户名为【 " + token.getPrincipal() + " 】密码错误！");
        } catch (LockedAccountException lae) {
            //LOGGER.info("用户名为【" + token.getPrincipal() + " 】的账户锁定，请联系管理员。");
            lae.printStackTrace();
            return AjaxJsonMap.error("用户名为【" + token.getPrincipal() + " 】的账户锁定，请联系管理员。");
        } catch (DisabledAccountException dax) {
            //LOGGER.info("用户名为:【" + token.getHost() + "】用户已经被禁用.");
            dax.printStackTrace();
            return AjaxJsonMap.error("用户名为:【" + token.getHost() + "】用户已经被禁用。");
        } catch (ExcessiveAttemptsException eae) {
            //LOGGER.info("用户名为:【" + token.getHost() + "】的用户登录次数过多，有暴力破解的嫌疑.");
            eae.printStackTrace();
            return AjaxJsonMap.error("用户名为:【" + token.getHost() + "】的用户登录次数过多，有暴力破解的嫌疑。");
        } catch (ExpiredCredentialsException eca) {
            //LOGGER.info("用户名为:【" + token.getHost() + "】用户凭证过期.");
            eca.printStackTrace();
            return AjaxJsonMap.error("用户名为:【" + token.getHost() + "】用户凭证过期.");
        } catch (AuthenticationException ae) {
            //LOGGER.info("用户名为:【" + token.getHost() + "】用户验证失败.");
            ae.printStackTrace();
            return AjaxJsonMap.error("用户名为:【" + token.getHost() + "】用户验证失败.");
        } catch (Exception e) {
            //LOGGER.info("别的异常信息。。。。具体查看继承关系");
            e.printStackTrace();
            return AjaxJsonMap.error("别的异常信息。。。。具体查看继承关系");
        }


//        User user = userDao.findByUsername(userInfo.getUserId());
//        System.out.println(user.getUserName());
       /* if (user == null || !user.getUserName().equals(userInfo.getUserPwd())) {
            ModelAndView mav = new ModelAndView();
            mav.setViewName("login");
            return mav;
        } else {
            session.setAttribute("user", user);
            ModelAndView mav = new ModelAndView();
            mav.setViewName("index");
            return mav;
        }*/

    }

}
