package cn.temptation.service.impl;

import cn.temptation.dao.UserDao;
import cn.temptation.domain.User;
import cn.temptation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: UserServiceImpl.java
 * Description:
 * Author: cyb
 * CreateDate: 2019-03-30
 * --------------------------------------------------------------
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    UserDao userDao;

    @Override
    public User userLogin(User user) {
        return userDao.userLogin(user);
    }

    @Override
    public User getByUserName(String username) {
        return userDao.getByUserName(username);
    }

}
