package cn.temptation.dao;

import cn.temptation.domain.User;
import org.springframework.stereotype.Repository;

@Repository
public interface UserDao {

	/**
	 *@description:用户登录验证
	 *@author:cyb
	 *@date: 2019-04-01 17:11
	*@param: user
	 *@return: cn.temptation.domain.User
	 */
	User userLogin(User user);

	 User findByUserId(String UserID);

	 /**
	  *@description: 根据用户名查询用户
	  *@author:cyb
	  *@date: 2019-04-02 11:06
	 *@param: username
	  *@return: cn.temptation.domain.User
	  */
	User getByUserName(String username);
}
