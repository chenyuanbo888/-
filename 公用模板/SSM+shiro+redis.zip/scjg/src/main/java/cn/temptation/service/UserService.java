package cn.temptation.service;

import cn.temptation.domain.User;

/**
 * 
 * @author 陈远波
 *
 */
public interface UserService {

    /**
     *@description:用户登录验证
     *@author:cyb
     *@date: 2019-04-01 17:10
    *@param: user
     *@return: cn.temptation.domain.User
     */
    User userLogin(User user);

    /**
     *@description: 根据用户名查询用户
     *@author:cyb
     *@date: 2019-03-30 10:03
    *@param: username
     *@return: cn.temptation.domain.User
     */
    User getByUserName(String username);
}
