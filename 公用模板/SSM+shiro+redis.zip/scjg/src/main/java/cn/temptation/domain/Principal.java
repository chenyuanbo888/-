package cn.temptation.domain;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: Principal.java
 * Description:
 * Author: cyb
 * CreateDate: 2019-03-30
 * --------------------------------------------------------------
 */
public class Principal implements Serializable {

    private static final long serialVersionUID = 1L;

    private String UserId;//用户id
    private String DepartId;//部门id
    private String UserType;//用户类型 GL-管理
    private String UserCode;
    private String UserName;//用户名
    private String UserPwd;//MD5加密后密码
    private String TrueName;//真实名称-用户名对应的真实名称
    private String Moblie;//手机
    private String IDCard;//身份证
    private String StateCode;
    private String Enabled;//1-可用  0-禁用
    private String Sort;//
    private String IsAdmin;//是否是管理员
    private String password;//用户原始密码
    private String lxdz;//联系地址
    private String fzr;//负责人
    private String fzrdh;//负责人电话
    private String lxr;//联系人
    private String lxrdh;//联系人电话
    private String mail;//邮箱
    private Date loginTime; // 最近登录时间

    public Principal() {
    }

    public Principal(User user, Date loginTime) {

        this.loginTime = loginTime;
        this.UserName=user.getUserName(); // 登录名

    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String userId) {
        UserId = userId;
    }

    public String getDepartId() {
        return DepartId;
    }

    public void setDepartId(String departId) {
        DepartId = departId;
    }

    public String getUserType() {
        return UserType;
    }

    public void setUserType(String userType) {
        UserType = userType;
    }

    public String getUserCode() {
        return UserCode;
    }

    public void setUserCode(String userCode) {
        UserCode = userCode;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getUserPwd() {
        return UserPwd;
    }

    public void setUserPwd(String userPwd) {
        UserPwd = userPwd;
    }

    public String getTrueName() {
        return TrueName;
    }

    public void setTrueName(String trueName) {
        TrueName = trueName;
    }

    public String getMoblie() {
        return Moblie;
    }

    public void setMoblie(String moblie) {
        Moblie = moblie;
    }

    public String getIDCard() {
        return IDCard;
    }

    public void setIDCard(String IDCard) {
        this.IDCard = IDCard;
    }

    public String getStateCode() {
        return StateCode;
    }

    public void setStateCode(String stateCode) {
        StateCode = stateCode;
    }

    public String getEnabled() {
        return Enabled;
    }

    public void setEnabled(String enabled) {
        Enabled = enabled;
    }

    public String getSort() {
        return Sort;
    }

    public void setSort(String sort) {
        Sort = sort;
    }

    public String getIsAdmin() {
        return IsAdmin;
    }

    public void setIsAdmin(String isAdmin) {
        IsAdmin = isAdmin;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getLxdz() {
        return lxdz;
    }

    public void setLxdz(String lxdz) {
        this.lxdz = lxdz;
    }

    public String getFzr() {
        return fzr;
    }

    public void setFzr(String fzr) {
        this.fzr = fzr;
    }

    public String getFzrdh() {
        return fzrdh;
    }

    public void setFzrdh(String fzrdh) {
        this.fzrdh = fzrdh;
    }

    public String getLxr() {
        return lxr;
    }

    public void setLxr(String lxr) {
        this.lxr = lxr;
    }

    public String getLxrdh() {
        return lxrdh;
    }

    public void setLxrdh(String lxrdh) {
        this.lxrdh = lxrdh;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }


    public Date getLoginTime() {
        return loginTime;
    }

    public void setLoginTime(Date loginTime) {
        this.loginTime = loginTime;
    }
}
