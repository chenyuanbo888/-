package cn.temptation.utils;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import java.util.Properties;

/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: PropertyConfigurer.java
 * Description:错误信息文件读取工具类
 * Author: cyb
 * CreateDate: 2019-01-18
 * --------------------------------------------------------------
 */
public class PropertyConfigurer extends PropertyPlaceholderConfigurer {
    private static Properties props;       // 存取properties配置文件key-value结果

    @Override
    protected void processProperties(ConfigurableListableBeanFactory beanFactoryToProcess, Properties props)
            throws BeansException {
        super.processProperties(beanFactoryToProcess, props);
        this.props = props;

    }

//输入配置文件中的key 获取对应的值
    public static String getProperty(String key){
        return  new String(props.getProperty(key));

    }

    public String getProperty(String key, String defaultValue) {
        return this.props.getProperty(key, defaultValue);
    }

    public Object setProperty(String key, String value) {
        return this.props.setProperty(key, value);
    }
}
