package cn.temptation.shiro.user.realm;


import cn.temptation.domain.Principal;
import cn.temptation.domain.User;
import cn.temptation.service.UserService;
import cn.temptation.shiro.UsernamePasswordLoginTypeToken;
import cn.temptation.service.RedisService;
import cn.temptation.utils.enums.AvailableEnum;
import org.apache.commons.lang.StringUtils;
import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *@description: 
 *@author:cyb
 *@date: 2019-03-30 10:34
*@param: null
 *@return: 
 */
public class UserRealm extends AuthorizingRealm {

    // 注入用户信息service
    @Autowired
    private UserService shiroUserService;

    @Autowired
    RedisService redisService;

    //public UserRealm(){
    //    this.setCachingEnabled(false);  // shiro的缓存机制 （好像是，还要确认一下）
    //}

    /**
     * @description: 认证方法，它主要做以下事情：
     * 1.检查提交的进行认证的令牌信息
     * 2.根据令牌信息从数据源（通常为DB）中获取用户信息
     * 3.对用户信息进行匹配验证
     * 4.如果验证通过返回一个封装了用户信息的AuthenticationInfo实例，验证不通过则抛出AuthenticationException异常
     * @author:
     * @date: 2019-01-10 9:43
     * @param: authenticationToken
     * @return: org.apache.shiro.authc.AuthenticationInfo
     */
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken authenticationToken) throws AuthenticationException {

        UsernamePasswordToken token = (UsernamePasswordToken) authenticationToken;
        String username = token.getUsername();
        if (StringUtils.isNotBlank(username)){
            /**检验验证码, 后期需要*/
//            String valid_code = redisService.get("LOGIN_AUTH_" + username);

            User user = shiroUserService.getByUserName(username);

            if (user == null) {
                throw new UnknownAccountException("用户不存在");
            }else {
                String status = user.getEnabled();// 1-可用 0-禁用
                if ("0".equals(status)){//
                    if (AvailableEnum.PROHIBIT.getIndex().equals(status) || AvailableEnum.NO_AVAIL.getIndex().equals(status)){
                        throw new DisabledAccountException("账号被禁用，请联系管理员。");
                    }
                }
                // 设置登录时间
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                Principal principal = new Principal(user, new Date());
                SimpleAuthenticationInfo authInfo = new SimpleAuthenticationInfo(
                        principal,//对象
                        user.getUserPwd(),//加密后的用户密码
                        getName()//realm的名称
                );
                return authInfo;
            }
        }
        return null;
    }

    /**
     * @description: 授权方法 （权限控制）
     * @author:
     * @date: 2019-01-10 9:44
     * @param: principalCollection
     * @return: org.apache.shiro.authz.AuthorizationInfo
     */
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principalCollection) {
        /**
         *
         * 流程
         * 1.根据用户user->2.获取角色id->3.根据角色id获取权限permission
         */
        //方法一：获得user对象
        //UserDetailDTO user = (UserDetailDTO) principalCollection.getPrimaryPrincipal();
        String loginName = String.valueOf(principalCollection.getPrimaryPrincipal());
        SimpleAuthorizationInfo info = new SimpleAuthorizationInfo();
        //获取permission
        //if (user != null) {
        //    //查询用户所有的权限
        //    List<Permission> permissionsByUser = null;//shiroService.getPermissionsByUser(user);
        //    if (permissionsByUser.size() != 0) {
        //        for (Permission p : permissionsByUser) {
        //
        //            info.addStringPermission(p.getUrl());
        //        }
        //        return info;
        //    }
        //}
        return null;
    }


}