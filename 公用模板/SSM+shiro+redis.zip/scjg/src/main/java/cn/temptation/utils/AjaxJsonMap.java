package cn.temptation.utils;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: WebRespon.java
 * Description:
 * Author: wangzhicheng
 * CreateDate: 2019/1/17
 * --------------------------------------------------------------
 */
public class AjaxJsonMap {

    public AjaxJsonMap() {
    }

    public static Map<String, Object> error() {
        return data(1, "ERROR", (Object)null);
    }

    public static Map<String, Object> error(String message) {
        return data(1, message, (Object)null);
    }

    public static Map<String, Object> error(Object result) {
        return data(1, "ERROR", result);
    }

    public static Map<String, Object> error(String message, Object result) {
        return data(1, message, result);
    }

    public static Map<String, Object> success() {
        return data(200, "OK", (Object)null);
    }

    public static Map<String, Object> success(String message) {
        return data(200, message, (Object)null);
    }

    public static Map<String, Object> success(Object result) {
        return data(200, "OK", result);
    }

    public static Map<String, Object> success(String message, Object result) {
        return data(200, message, result);
    }

    public static Map<String, Object> data(int code, String message, Object result) {
        Map<String, Object> data = new HashMap();
        data.put("code", code);
        data.put("message", message == null ? "" : message);
        data.put("data", result == null ? "" : result);
        return data;
    }

    public static void alert(HttpServletRequest request, HttpServletResponse response, String message) {
        StringBuffer msg = new StringBuffer();
        msg.append("<script>window.alert('");
        msg.append(message);
        msg.append("');window.history.go(-1);</script>");
        ServletOutputStream out = null;

        try {
            out = response.getOutputStream();
            response.setContentType("text/html");
            out.write(msg.toString().getBytes("UTF-8"));
        } catch (Exception var14) {
            var14.printStackTrace();
        } finally {
            try {
                out.flush();
                out.close();
            } catch (IOException var13) {
                var13.printStackTrace();
            }

        }

    }

    public static void redirect(HttpServletRequest request, HttpServletResponse response, String url, String message) {
        StringBuffer msg = new StringBuffer();
        msg.append("<script>window.alert('");
        msg.append(message);
        msg.append("');window.location.replace('" + request.getServletContext().getContextPath() + "/" + url + "');</script>");
        ServletOutputStream out = null;

        try {
            out = response.getOutputStream();
            response.setContentType("text/html");
            out.write(msg.toString().getBytes("UTF-8"));
        } catch (Exception var15) {
            var15.printStackTrace();
        } finally {
            try {
                out.flush();
                out.close();
            } catch (IOException var14) {
                var14.printStackTrace();
            }

        }

    }

}
