package com.juno.weixin.modules.controller;

import com.juno.weixin.modules.common.util.AccessToken;
import com.juno.weixin.modules.common.util.WeixinUtil;
import com.juno.weixin.modules.common.wx.WxConstants;
import com.juno.weixin.modules.common.wx.WxUtil;
import net.sf.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.HttpServletRequest;
import java.net.URLEncoder;

/**
 * --------------------------------------------------------------
 * CopyRights(c)2018,YJLC
 * All Rights Reserved
 * <p>
 * FileName: MyWxController.java
 * Description:
 * Author: ljx
 * CreateDate: 2019-02-28
 * --------------------------------------------------------------
 */
@Controller
public class MyWxController {

    //首次进入
    @RequestMapping(value = "/redirect", method = RequestMethod.GET)
    public String getCode(String appid,String redirect_uri,String scope){
        try {
            appid="wxab8acb865bb1637e";
            scope="snsapi_base";
            String url="http://www.cdyjlc.com:8080/oauth";//进入回调地址
            String redirectURL= URLEncoder.encode(url, "UTF-8");
            String requestUrl ="redirect:"+WxConstants.GET_CODE.replace("APPID", appid).replace("REDIRECT_URI", redirectURL).replace("SCOPE", scope);
            return requestUrl;
        }catch (Exception e){
            e.printStackTrace();
        }
        return "";
    }

    //回调地址访问
    @RequestMapping("oauth")
    public void getToken(HttpServletRequest request){
        String appid="wxab8acb865bb1637e"; //开发ID
        String appsecret="86ae4a77893342f7568947e243c84d9aa"; //开发秘钥
        String code=request.getParameter("code"); //获取code
        AccessToken token= WeixinUtil.getAcToken(appid,appsecret,code);
        token.getToken();//获取token
        token.getOpenId();// 获取用户oppenId

        //跳转前端页面
    }



}
