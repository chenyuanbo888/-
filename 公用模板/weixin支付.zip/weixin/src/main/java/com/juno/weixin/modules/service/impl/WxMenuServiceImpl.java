package com.juno.weixin.modules.service.impl;

import com.juno.weixin.modules.common.http.HttpsClient;
import com.juno.weixin.modules.common.wx.WxConfig;
import com.juno.weixin.modules.common.wx.WxConstants;
import com.juno.weixin.modules.common.wx.WxUtil;
import com.juno.weixin.modules.service.WxMenuService;
import net.sf.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * 微信菜单实现类类
 * @author lujunjie
 * @date   2018/02/16
 */
@Service("wxMenuService")
public class WxMenuServiceImpl implements WxMenuService {

    @Override
    public String wxPayUrl(Double totalFee,String outTradeNo,String signType) throws Exception {
        HashMap<String, String> data = new HashMap<String, String>();
        //公众账号ID
        data.put("appid", WxConfig.appID);
        //商户号
        data.put("mch_id", WxConfig.mchID);
        //随机字符串
        data.put("nonce_str", WxUtil.getNonceStr());
        //商品描述
        data.put("body","测试支付");
        //商户订单号
        data.put("out_trade_no",outTradeNo);
        //标价币种
        data.put("fee_type","CNY");
        //标价金额
        data.put("total_fee",String.valueOf(Math.round(totalFee * 100)));
        //用户的IP
        data.put("spbill_create_ip","123.12.12.123");
        //通知地址
        data.put("notify_url",WxConfig.unifiedorderNotifyUrl);
        //交易类型
        data.put("trade_type","NATIVE");//JSAPI /NATIVE/APP
        //用户oppenId
//        data.put("openid","oUpF8uMuAJO_M2pxb1Q9zNjWeS6o");
        //签名类型
        data.put("sign_type",signType);
        //签名
        data.put("sign",WxUtil.getSignature(data, WxConfig.key,signType));

        String requestXML = WxUtil.mapToXml(data);
        String reponseString = HttpsClient.httpsRequestReturnString(WxConstants.PAY_UNIFIEDORDER,HttpsClient.METHOD_POST,requestXML);
        Map<String,String> resultMap = WxUtil.processResponseXml(reponseString,signType);
        System.out.println("下单结果");
        System.out.println(resultMap);
        if(resultMap.get(WxConstants.RETURN_CODE).equals("SUCCESS")){
//            return sendPay("wxab8acb865bb1637e",resultMap.get("prepay_id"));
         return resultMap.get("code_url");
        }
        return null;
    }



    /**
     * 发起支付
     * @param
     * @param prepayId
     * @return
     * @throws Exception
     */
    public String sendPay(String appId, String prepayId) throws Exception {
        SortedMap<Object, Object> parameters = new TreeMap<Object, Object>();
        parameters.put("appId", appId);
        parameters.put("nonceStr", getRandomStr(16));
        parameters.put("package", "prepay_id=" + prepayId);
        parameters.put("signType", "MD5");
        parameters.put("timeStamp", String.valueOf(System.currentTimeMillis() / 1000));

        String characterEncoding = "UTF-8";
        // 支付签名
        String paySign = createSign(characterEncoding, parameters);
        parameters.put("paySign", paySign);
        JSONObject jsonObject = JSONObject.fromObject(parameters);
        return jsonObject.toString();
    }

    /**
     * 获取随机字符串
     * @param length
     * @return
     */
    public String getRandomStr(int length) {
        String base = "abcdefghijklmnopqrstuvwxyz0123456789";
        int randomNum;
        char randomChar;
        Random random = new Random();
        // StringBuffer类型的可以append增加字符
        StringBuffer str = new StringBuffer();
        for (int i = 0; i < length; i++) {
            // 可生成[0,n)之间的整数，获得随机位置
            randomNum = random.nextInt(base.length());
            // 获得随机位置对应的字符
            randomChar = base.charAt(randomNum);
            // 组成一个随机字符串
            str.append(randomChar);
        }
        return str.toString().toUpperCase();
    }

    public static String createSign(String characterEncoding,SortedMap<Object,Object> parameters) throws Exception{
        StringBuffer sb = new StringBuffer();
        Set es = parameters.entrySet();//所有参与传参的参数按照accsii排序（升序）
        Iterator it = es.iterator();
        while(it.hasNext()) {
            Map.Entry entry = (Map.Entry)it.next();
            String k = (String)entry.getKey();
            Object v = entry.getValue();
            if(null != v && !"".equals(v)
                    && !"sign".equals(k) && !"key".equals(k)) {
                sb.append(k + "=" + v + "&");
            }
        }
        String miyao="2ab9071b06b9f739b950ddb41db2690d";//商户秘钥
        sb.append("key=" +miyao);
//        System.out.println("sb.toString()" + sb.toString());
        String sign = WxUtil.MD5(sb.toString()).toUpperCase();
//        System.out.println("sign-----:" + sign);
        return sign;
    }


}
